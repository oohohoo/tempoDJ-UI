
            import Home from "./../../../../../components/home.tsx";

            const TempoComponent = () => {
              return <Home />;
            }

            

            export default TempoComponent;