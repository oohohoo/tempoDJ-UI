
            import MixTimeline from "./../../../../../../components/mixCreator/MixTimeline.tsx";

            const TempoComponent = () => {
              return <MixTimeline />;
            }

            

            export default TempoComponent;